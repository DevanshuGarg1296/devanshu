#!/usr/bin/env php
<?php

error_reporting(0);

if (!isset($called_by_script_server)) {
	include_once(dirname(__FILE__) . '/../include/cli_check.php');
	include_once(dirname(__FILE__) . '/../lib/snmp.php');

	array_shift($_SERVER['argv']);

	print call_user_func_array('ss_cisco_poe', $_SERVER['argv']);
} else {
	include_once(dirname(__FILE__) . '/../lib/snmp.php');
}

function ss_cisco_poe($hostname = '', $host_id = 0, $snmp_auth = '', $cmd = 'index', $arg1 = '', $arg2 = '') {
	$snmp = explode(':', $snmp_auth);
	$snmp_version   = $snmp[0];
	$snmp_port      = $snmp[1];
	$snmp_timeout   = $snmp[2];
	$ping_retries   = $snmp[3];
	$max_oids       = $snmp[4];

	$snmp_auth_username   = '';
	$snmp_auth_password   = '';
	$snmp_auth_protocol   = '';
	$snmp_priv_passphrase = '';
	$snmp_priv_protocol   = '';
	$snmp_context         = '';
	$snmp_community       = '';

	if ($snmp_version == 3) {
		$snmp_auth_username   = $snmp[6];
		$snmp_auth_password   = $snmp[7];
		$snmp_auth_protocol   = $snmp[8];
		$snmp_priv_passphrase = $snmp[9];
		$snmp_priv_protocol   = $snmp[10];
		$snmp_context         = $snmp[11];
	} else {
		$snmp_community = $snmp[5];
	}

	$oids = array(
		'used'        => '.1.3.6.1.4.1.9.9.402.1.2.1.9.1',
		'maxused'     => '.1.3.6.1.4.1.9.9.402.1.2.1.10.1',
		'index'       => '.1.3.6.1.4.1.9.9.402.1.2.1.11.1',
		'descindex'   => '.1.3.6.1.4.1.9.9.402.1.2.1.11.1',
		'description' => '.1.3.6.1.4.1.9.9.402.1.2.1.11.1',
		'max'         => '.1.3.6.1.4.1.9.9.402.1.2.1.8.1'
	);

	if ($cmd == 'index') {
		$return_arr = ss_cisco_poe_index(
			cacti_snmp_walk($hostname, $snmp_community, $oids['index'], $snmp_version, $snmp_auth_username,
				$snmp_auth_password, $snmp_auth_protocol, $snmp_priv_passphrase, $snmp_priv_protocol,
				$snmp_context, $snmp_port, $snmp_timeout, $ping_retries, $max_oids, SNMP_POLLER)
			);

		if (cacti_sizeof($return_arr)) {
			foreach ($return_arr as $item) {
				print $item . "\n";
			}
		}
	} elseif ($cmd == 'num_indexes') {
		$return_arr = ss_cisco_poe_index(
			cacti_snmp_walk($hostname, $snmp_community, $oids['index'], $snmp_version, $snmp_auth_username,
				$snmp_auth_password, $snmp_auth_protocol, $snmp_priv_passphrase, $snmp_priv_protocol,
				$snmp_context, $snmp_port, $snmp_timeout, $ping_retries, $max_oids, SNMP_POLLER)
			);

		return cacti_sizeof($return_arr);
	} elseif ($cmd == 'query') {
		$arg = $arg1;

		$arr_index = ss_cisco_poe_index(
			cacti_snmp_walk($hostname, $snmp_community, $oids['index'], $snmp_version, $snmp_auth_username,
				$snmp_auth_password, $snmp_auth_protocol, $snmp_priv_passphrase, $snmp_priv_protocol,
				$snmp_context, $snmp_port, $snmp_timeout, $ping_retries, $max_oids, SNMP_POLLER)
			);

		if (cacti_sizeof($arr_index)) {
			$arr = ss_cisco_poe_reindex(
				cacti_snmp_walk($hostname, $snmp_community, $oids[$arg], $snmp_version, $snmp_auth_username,
					$snmp_auth_password, $snmp_auth_protocol, $snmp_priv_passphrase, $snmp_priv_protocol,
					$snmp_context, $snmp_port, $snmp_timeout, $ping_retries, $max_oids, SNMP_POLLER)
				);
				
			if ($arg == 'description') {
				$ddeesscc = cacti_snmp_walk($hostname, $snmp_community, '.1.3.6.1.2.1.47.1.1.1.1.2', $snmp_version, $snmp_auth_username,
					$snmp_auth_password, $snmp_auth_protocol, $snmp_priv_passphrase, $snmp_priv_protocol,
					$snmp_context, $snmp_port, $snmp_timeout, $ping_retries, $max_oids, SNMP_POLLER);
				for ($i=0;($i<sizeof($ddeesscc));$i++) {
					$ttt = pathinfo($ddeesscc[$i]['oid'], PATHINFO_EXTENSION);
					$key = array_search($ttt,$arr);
					if ($key !== false) {
						$arr[$key] = $ddeesscc[$i]['value'];
					}
				}
			}

			if ($arg == 'index') {
				for ($i=0;($i<sizeof($arr));$i++) {
						$arr[$i] = $arr_index[$i];
				}
			}

			if (cacti_sizeof($arr)) {
				for ($i=0;($i<cacti_sizeof($arr_index));$i++) {
					if (isset($arr[$i])) {
						print $arr_index[$i] . '!' . $arr[$i] . "\n";
					} else {
						print $arr_index[$i] . '!' . "Unknown\n";
					}
				}
			} else {
				return '';
			}
		} else {
			return '';
		}
	} elseif ($cmd == 'get') {
		$arg   = $arg1;
		$index = $arg2;

		return cacti_snmp_get($hostname, $snmp_community, $oids[$arg] . ".$index", $snmp_version,
			$snmp_auth_username, $snmp_auth_password, $snmp_auth_protocol, $snmp_priv_passphrase,
			$snmp_priv_protocol, $snmp_context, $snmp_port, $snmp_timeout, $ping_retries, SNMP_POLLER);
	}
}

function ss_cisco_poe_index($arr) {
	$return_arr = array();

	if (cacti_sizeof($arr)) {
		for ($i=0;($i<cacti_sizeof($arr));$i++) {
			if (!isset($arr[$i]['value'])) {
				return array();
			}
			$return_arr[$i] = pathinfo($arr[$i]['oid'], PATHINFO_EXTENSION);
		}
	}
	return $return_arr;
}

function ss_cisco_poe_reindex($arr) {
	$return_arr = array();

	if (cacti_sizeof($arr)) {
		for ($i=0;($i<cacti_sizeof($arr));$i++) {
			if (!isset($arr[$i]['value'])) {
				return array();
			}
			$return_arr[$i] = $arr[$i]['value'];
		}
	}
	return $return_arr;
}
