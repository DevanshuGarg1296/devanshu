#!/usr/bin/env php
<?php
 
global $config;
 
if (!isset($called_by_script_server)) {
    include_once(dirname(__FILE__) . '/../include/cli_check.php');
    include_once(dirname(__FILE__) . '/../lib/snmp.php');
 
    array_shift($_SERVER['argv']);
    print call_user_func_array('cisco_nexus_memory', $_SERVER['argv']);
} else {
    include_once(dirname(__FILE__) . '/../lib/snmp.php');
}
 
function cisco_nexus_memory($host_id = 0) {
    global $environ, $poller_id, $config;
 
    $log_file = '/tmp/cisco_nexus_memory_debug.log';
    $time     = date('Y-m-d H:i:s');
 
    if (empty($host_id) || !is_numeric($host_id)) {
        file_put_contents($log_file, "[$time] ERROR: Invalid host_id=[$host_id]\n", FILE_APPEND);
        return 'used_mem:0 free_mem:0' . PHP_EOL;
    }
 
    file_put_contents($log_file, "[$time] START: host_id=[$host_id]\n", FILE_APPEND);
 
    $host = db_fetch_row_prepared('SELECT * FROM host WHERE id = ?', array($host_id));
 
    if (empty($host)) {
        file_put_contents($log_file, "[$time] ERROR: Host not found id=[$host_id]\n", FILE_APPEND);
        return 'used_mem:0 free_mem:0' . PHP_EOL;
    }
 
    file_put_contents($log_file, "[$time] HOST: hostname=[{$host['hostname']}] community=[{$host['snmp_community']}]\n", FILE_APPEND);
 
    // Used Memory
    $used_mem = cacti_snmp_get(
        $host['hostname'],
        $host['snmp_community'],
        '.1.3.6.1.4.1.9.9.109.1.1.1.1.12.1',
        $host['snmp_version'],
        $host['snmp_username'],
        $host['snmp_password'],
        $host['snmp_auth_protocol'],
        $host['snmp_priv_passphrase'],
        $host['snmp_priv_protocol'],
        $host['snmp_context'],
        $host['snmp_port'],
        $host['snmp_timeout'],
        $host['ping_retries'],
        SNMP_POLLER,
        $host['snmp_engine_id']
    );
 
    file_put_contents($log_file, "[$time] SNMP USED MEM: result=[$used_mem]\n", FILE_APPEND);
 
    // Free Memory
    $free_mem = cacti_snmp_get(
        $host['hostname'],
        $host['snmp_community'],
        '.1.3.6.1.4.1.9.9.109.1.1.1.1.13.1',
        $host['snmp_version'],
        $host['snmp_username'],
        $host['snmp_password'],
        $host['snmp_auth_protocol'],
        $host['snmp_priv_passphrase'],
        $host['snmp_priv_protocol'],
        $host['snmp_context'],
        $host['snmp_port'],
        $host['snmp_timeout'],
        $host['ping_retries'],
        SNMP_POLLER,
        $host['snmp_engine_id']
    );
 
    file_put_contents($log_file, "[$time] SNMP FREE MEM: result=[$free_mem]\n", FILE_APPEND);
 
    $used_mem = is_numeric($used_mem) ? $used_mem : 0;
    $free_mem = is_numeric($free_mem) ? $free_mem : 0;
 
    $output = 'used_mem:' . $used_mem . ' free_mem:' . $free_mem;
 
    file_put_contents($log_file, "[$time] OUTPUT: $output\n", FILE_APPEND);
    file_put_contents($log_file, "[$time] END ----------------------------\n", FILE_APPEND);
 
    return $output . PHP_EOL;
}
?>
