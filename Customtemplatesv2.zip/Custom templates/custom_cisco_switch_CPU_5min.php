#!/usr/bin/env php
<?php
 
global $config;
 
if (!isset($called_by_script_server)) {
    include_once(dirname(__FILE__) . '/../include/cli_check.php');
    include_once(dirname(__FILE__) . '/../lib/snmp.php');
 
    array_shift($_SERVER['argv']);
    print call_user_func_array('cisco_nexus_cpu', $_SERVER['argv']);
} else {
    include_once(dirname(__FILE__) . '/../lib/snmp.php');
}
 
function cisco_nexus_cpu($host_id = 0) {
    global $environ, $poller_id, $config;
 
    $log_file = '/tmp/cisco_nexus_cpu_debug.log';
    $time     = date('Y-m-d H:i:s');
 
    if (empty($host_id) || !is_numeric($host_id)) {
        file_put_contents($log_file, "[$time] ERROR: Invalid host_id=[$host_id]\n", FILE_APPEND);
        return 'cpu:0' . PHP_EOL;
    }
 
    file_put_contents($log_file, "[$time] START: host_id=[$host_id]\n", FILE_APPEND);
 
    $host = db_fetch_row_prepared('SELECT * FROM host WHERE id = ?', array($host_id));
 
    if (empty($host)) {
        file_put_contents($log_file, "[$time] ERROR: Host not found id=[$host_id]\n", FILE_APPEND);
        return 'cpu:0' . PHP_EOL;
    }
 
    file_put_contents($log_file, "[$time] HOST: hostname=[{$host['hostname']}] community=[{$host['snmp_community']}]\n", FILE_APPEND);
 
    $cpu = cacti_snmp_get(
        $host['hostname'],
        $host['snmp_community'],
        '.1.3.6.1.4.1.9.9.109.1.1.1.1.8.1',
        $host['snmp_version'],
        $host['snmp_username'],
        $host['snmp_password'],
        $host['snmp_auth_protocol'],
        $host['snmp_priv_passphrase'],
        $host['snmp_priv_protocol'],
        $host['snmp_context'],
        $host['snmp_port'],
        $host['snmp_timeout'],
        $host['ping_retries'],
        SNMP_POLLER,
        $host['snmp_engine_id']
    );
 
    $cpu = is_numeric($cpu) ? $cpu : 0;
 
    file_put_contents($log_file, "[$time] OUTPUT: cpu:$cpu\n", FILE_APPEND);
    file_put_contents($log_file, "[$time] END ----------------------------\n", FILE_APPEND);
 
    return 'cpu:' . $cpu . PHP_EOL;
}
?>
