#!/usr/bin/env php
<?php
 
global $config;
 
if (!isset($called_by_script_server)) {
    include_once(dirname(__FILE__) . '/../include/cli_check.php');
    include_once(dirname(__FILE__) . '/../lib/snmp.php');
 
    array_shift($_SERVER['argv']);
    print call_user_func_array('cisco_memory', $_SERVER['argv']);
} else {
    include_once(dirname(__FILE__) . '/../lib/snmp.php');
}
 
function cisco_memory($host_id = 0) {
    global $environ, $poller_id, $config;
 
    $log_file = '/tmp/cisco_memory_debug.log';
    $time     = date('Y-m-d H:i:s');
 
    // Host ID check
    if (empty($host_id) || $host_id === NULL || !is_numeric($host_id)) {
        file_put_contents($log_file, "[$time] ERROR: Invalid host_id=[$host_id]\n", FILE_APPEND);
        return 'free:0 buffer:0' . PHP_EOL;
    }
 
    file_put_contents($log_file, "[$time] START: host_id=[$host_id]\n", FILE_APPEND);
 
    // DB se device detail
    $host = db_fetch_row_prepared('SELECT * FROM host WHERE id = ?', array($host_id));
 
    if (empty($host)) {
        file_put_contents($log_file, "[$time] ERROR: Host not found in DB for id=[$host_id]\n", FILE_APPEND);
        return 'free:0 buffer:0' . PHP_EOL;
    }
 
    file_put_contents($log_file, "[$time] HOST: hostname=[{$host['hostname']}] community=[{$host['snmp_community']}] version=[{$host['snmp_version']}]\n", FILE_APPEND);
 
    // Free Memory OID
    $free_result = cacti_snmp_get(
        $host['hostname'],
        $host['snmp_community'],
        '.1.3.6.1.4.1.9.9.48.1.1.1.6.1',
        $host['snmp_version'],
        $host['snmp_username'],
        $host['snmp_password'],
        $host['snmp_auth_protocol'],
        $host['snmp_priv_passphrase'],
        $host['snmp_priv_protocol'],
        $host['snmp_context'],
        $host['snmp_port'],
        $host['snmp_timeout'],
        $host['ping_retries'],
        SNMP_POLLER,
        $host['snmp_engine_id']
    );
 
    file_put_contents($log_file, "[$time] SNMP FREE: result=[$free_result]\n", FILE_APPEND);
 
    // Buffer Memory OID
    $buffer_result = cacti_snmp_get(
        $host['hostname'],
        $host['snmp_community'],
        '.1.3.6.1.4.1.9.9.48.1.1.1.6.2',
        $host['snmp_version'],
        $host['snmp_username'],
        $host['snmp_password'],
        $host['snmp_auth_protocol'],
        $host['snmp_priv_passphrase'],
        $host['snmp_priv_protocol'],
        $host['snmp_context'],
        $host['snmp_port'],
        $host['snmp_timeout'],
        $host['ping_retries'],
        SNMP_POLLER,
        $host['snmp_engine_id']
    );
 
    file_put_contents($log_file, "[$time] SNMP BUFFER: result=[$buffer_result]\n", FILE_APPEND);
 
    $free   = is_numeric($free_result)   ? $free_result   : 0;
    $buffer = is_numeric($buffer_result) ? $buffer_result : 0;
 
    $output = 'free:' . $free . ' buffer:' . $buffer;
 
    file_put_contents($log_file, "[$time] OUTPUT: $output\n", FILE_APPEND);
    file_put_contents($log_file, "[$time] END ----------------------------\n", FILE_APPEND);
 
    return $output . PHP_EOL;
}
?>